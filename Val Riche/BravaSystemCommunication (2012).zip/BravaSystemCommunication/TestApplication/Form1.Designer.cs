namespace TestApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConnect = new System.Windows.Forms.Button();
            this.txtIPAddr = new System.Windows.Forms.TextBox();
            this.txtIPPort = new System.Windows.Forms.TextBox();
            this.btnReadingRq = new System.Windows.Forms.Button();
            this.btnTypeSampleXML = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.button2 = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.btnConnectSw = new System.Windows.Forms.Button();
            this.btnDisconnectSw = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnGetStateBlock = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtAlertPortNum = new System.Windows.Forms.TextBox();
            this.txtAlertIPAddress = new System.Windows.Forms.TextBox();
            this.numRouteRuleNum = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRouteRuleNum)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(15, 74);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(127, 46);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txtIPAddr
            // 
            this.txtIPAddr.Location = new System.Drawing.Point(15, 34);
            this.txtIPAddr.Name = "txtIPAddr";
            this.txtIPAddr.Size = new System.Drawing.Size(164, 20);
            this.txtIPAddr.TabIndex = 1;
            this.txtIPAddr.Text = "IPaddress";
            // 
            // txtIPPort
            // 
            this.txtIPPort.Location = new System.Drawing.Point(175, 34);
            this.txtIPPort.Name = "txtIPPort";
            this.txtIPPort.Size = new System.Drawing.Size(108, 20);
            this.txtIPPort.TabIndex = 2;
            this.txtIPPort.Text = "9000";
            // 
            // btnReadingRq
            // 
            this.btnReadingRq.Location = new System.Drawing.Point(18, 38);
            this.btnReadingRq.Name = "btnReadingRq";
            this.btnReadingRq.Size = new System.Drawing.Size(125, 49);
            this.btnReadingRq.TabIndex = 3;
            this.btnReadingRq.Text = "Get Reading";
            this.btnReadingRq.UseVisualStyleBackColor = true;
            this.btnReadingRq.Click += new System.EventHandler(this.btnReadingRq_Click);
            // 
            // btnTypeSampleXML
            // 
            this.btnTypeSampleXML.Location = new System.Drawing.Point(158, 85);
            this.btnTypeSampleXML.Name = "btnTypeSampleXML";
            this.btnTypeSampleXML.Size = new System.Drawing.Size(92, 25);
            this.btnTypeSampleXML.TabIndex = 4;
            this.btnTypeSampleXML.Text = "Sample XML";
            this.btnTypeSampleXML.UseVisualStyleBackColor = true;
            this.btnTypeSampleXML.Click += new System.EventHandler(this.btnTypeSampleXML_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(18, 128);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(226, 20);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "MessageText";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(18, 155);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 54);
            this.button1.TabIndex = 6;
            this.button1.Text = "Display Message";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(250, 129);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(35, 20);
            this.numericUpDown1.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(160, 155);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 54);
            this.button2.TabIndex = 8;
            this.button2.Text = "Erase Message";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(32, 30);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(71, 19);
            this.radioButton1.TabIndex = 9;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Switch 1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(32, 55);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(71, 19);
            this.radioButton2.TabIndex = 10;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Switch 2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(32, 80);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(71, 19);
            this.radioButton3.TabIndex = 11;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Switch 3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(32, 105);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(71, 19);
            this.radioButton4.TabIndex = 12;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Switch 4";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // btnConnectSw
            // 
            this.btnConnectSw.Location = new System.Drawing.Point(166, 30);
            this.btnConnectSw.Name = "btnConnectSw";
            this.btnConnectSw.Size = new System.Drawing.Size(138, 38);
            this.btnConnectSw.TabIndex = 13;
            this.btnConnectSw.Text = "Connect Switch";
            this.btnConnectSw.UseVisualStyleBackColor = true;
            this.btnConnectSw.Click += new System.EventHandler(this.btnConnectSw_Click);
            // 
            // btnDisconnectSw
            // 
            this.btnDisconnectSw.Location = new System.Drawing.Point(166, 89);
            this.btnDisconnectSw.Name = "btnDisconnectSw";
            this.btnDisconnectSw.Size = new System.Drawing.Size(138, 35);
            this.btnDisconnectSw.TabIndex = 14;
            this.btnDisconnectSw.Text = "Disconnect Switch";
            this.btnDisconnectSw.UseVisualStyleBackColor = true;
            this.btnDisconnectSw.Click += new System.EventHandler(this.btnDisconnectSw_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnConnectSw);
            this.groupBox1.Controls.Add(this.btnDisconnectSw);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Location = new System.Drawing.Point(17, 215);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(342, 144);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Four way load switch";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox5);
            this.groupBox2.Controls.Add(this.checkBox6);
            this.groupBox2.Controls.Add(this.checkBox7);
            this.groupBox2.Controls.Add(this.checkBox8);
            this.groupBox2.Controls.Add(this.checkBox4);
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Controls.Add(this.checkBox1);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Location = new System.Drawing.Point(29, 74);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(382, 148);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Eight way contactor controller";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(18, 58);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(69, 19);
            this.checkBox5.TabIndex = 8;
            this.checkBox5.Text = "Switch5";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(110, 58);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(69, 19);
            this.checkBox6.TabIndex = 7;
            this.checkBox6.Text = "Switch6";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(202, 58);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(69, 19);
            this.checkBox7.TabIndex = 6;
            this.checkBox7.Text = "Switch7";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(294, 58);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(69, 19);
            this.checkBox8.TabIndex = 5;
            this.checkBox8.Text = "Switch8";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(294, 28);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(69, 19);
            this.checkBox4.TabIndex = 4;
            this.checkBox4.Text = "Switch4";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(202, 28);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(69, 19);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "Switch3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(110, 28);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(69, 19);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "Switch2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(18, 28);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(69, 19);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "Switch1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(91, 108);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(138, 34);
            this.button3.TabIndex = 0;
            this.button3.Text = "Send Switch State";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(15, 196);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(607, 420);
            this.tabControl1.TabIndex = 17;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.btnReadingRq);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.numericUpDown1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(599, 380);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Older Brava System 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.btnGetStateBlock);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(599, 394);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Brava System Multi";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnGetStateBlock
            // 
            this.btnGetStateBlock.Location = new System.Drawing.Point(29, 24);
            this.btnGetStateBlock.Name = "btnGetStateBlock";
            this.btnGetStateBlock.Size = new System.Drawing.Size(146, 44);
            this.btnGetStateBlock.TabIndex = 17;
            this.btnGetStateBlock.Text = "Get State Block";
            this.btnGetStateBlock.UseVisualStyleBackColor = true;
            this.btnGetStateBlock.Click += new System.EventHandler(this.btnGetStateBlock_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.numRouteRuleNum);
            this.groupBox3.Controls.Add(this.txtAlertPortNum);
            this.groupBox3.Controls.Add(this.txtAlertIPAddress);
            this.groupBox3.Location = new System.Drawing.Point(29, 228);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(382, 131);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Configure Alert Message Server";
            // 
            // txtAlertPortNum
            // 
            this.txtAlertPortNum.Location = new System.Drawing.Point(256, 45);
            this.txtAlertPortNum.Name = "txtAlertPortNum";
            this.txtAlertPortNum.Size = new System.Drawing.Size(108, 20);
            this.txtAlertPortNum.TabIndex = 4;
            this.txtAlertPortNum.Text = "9001";
            // 
            // txtAlertIPAddress
            // 
            this.txtAlertIPAddress.Location = new System.Drawing.Point(92, 45);
            this.txtAlertIPAddress.Name = "txtAlertIPAddress";
            this.txtAlertIPAddress.Size = new System.Drawing.Size(164, 20);
            this.txtAlertIPAddress.TabIndex = 3;
            this.txtAlertIPAddress.Text = "Alert Server IP Address";
            // 
            // numRouteRuleNum
            // 
            this.numRouteRuleNum.Location = new System.Drawing.Point(11, 46);
            this.numRouteRuleNum.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numRouteRuleNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numRouteRuleNum.Name = "numRouteRuleNum";
            this.numRouteRuleNum.Size = new System.Drawing.Size(78, 20);
            this.numRouteRuleNum.TabIndex = 5;
            this.numRouteRuleNum.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Route Rule #";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(92, 82);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(138, 43);
            this.button4.TabIndex = 7;
            this.button4.Text = "Send Configuration";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 628);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnTypeSampleXML);
            this.Controls.Add(this.txtIPPort);
            this.Controls.Add(this.txtIPAddr);
            this.Controls.Add(this.btnConnect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRouteRuleNum)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtIPAddr;
        private System.Windows.Forms.TextBox txtIPPort;
        private System.Windows.Forms.Button btnReadingRq;
        private System.Windows.Forms.Button btnTypeSampleXML;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Button btnConnectSw;
        private System.Windows.Forms.Button btnDisconnectSw;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnGetStateBlock;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numRouteRuleNum;
        private System.Windows.Forms.TextBox txtAlertPortNum;
        private System.Windows.Forms.TextBox txtAlertIPAddress;
        private System.Windows.Forms.Button button4;
    }
}

