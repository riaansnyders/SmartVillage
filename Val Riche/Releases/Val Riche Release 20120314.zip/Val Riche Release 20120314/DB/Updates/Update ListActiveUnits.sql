USE [lfa_PowerMgmt]
GO
/****** Object:  StoredProcedure [Schedule].[ListActiveUnit]    Script Date: 03/14/2012 20:16:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ================================================
-- Author:		Riaan Snyders
-- Create date: 31 December 2011
-- Description:	Return a list of active units
-- ================================================
ALTER Procedure [Schedule].[ListActiveUnit]
  @Id_Schedule int
As
 SET NOCOUNT ON
 
	SELECT cfunit.Id, unit.Id as 'Id_ScheduleUnit', cfunit.Name, cfunit.[Address], cfunit.DateAdded, cfunit.IsActive
	FROM [Schedule].[Unit] unit
	INNER JOIN [Configuration].[Unit] cfunit on cfunit.Id = unit.Id_Unit
	WHERE unit.Id_Schedule = @Id_Schedule
